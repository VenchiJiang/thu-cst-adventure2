python3 exp1.py -nf 2
python3 exp1.py -nf 4
python3 exp1.py -nf 8
python3 exp1.py -nf 16
python3 exp1.py -nf 32
python3 exp1.py -nf 64
python3 exp1.py -nf 128
python3 exp1.py -nf 2 -sn 'semicircle'
python3 exp1.py -nf 4 -sn 'semicircle'
python3 exp1.py -nf 8 -sn 'semicircle'
python3 exp1.py -nf 16 -sn 'semicircle'
python3 exp1.py -nf 32 -sn 'semicircle'
python3 exp1.py -nf 64 -sn 'semicircle'
python3 exp1.py -nf 128 -sn 'semicircle'